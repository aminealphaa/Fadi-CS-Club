let iconBtn = document.getElementById('icon')
let menu = document.getElementById('menu')

// iconBtn.addEventListener('click', () => {
//     if (menu.style.transform === 'translateY(-2000%)'){
//         menu.style.transform = 'translateY(0%)'
//     }else{
//         menu.style.transform = 'trmaslateY(-2000%)'
//     }
// })
iconBtn.addEventListener('click', () => {
    if (menu.style.transform === 'translateY(-2000%)'){
    menu.style.transform = 'translateY(0%)'
    }else{
    menu.style.transform = 'translateY(-2000%)'
    }
})
let form = document.getElementById('theform')
let btn1 = document.getElementById('special1')
let btn2 = document.getElementById('special2')
let closer = document.getElementById('closer')
let username1 = document.getElementById('name')
let passw = document.getElementById('pass')
let loginLink = document.getElementById('login')
let signUp = document.getElementById('sign-up')

btn1.addEventListener('click', () => {
    form.style.transform = 'translate(-50%, -50%)'
})


btn2.addEventListener('click', () => {
    form.style.transform = 'translate(-50%, -50%)'
})
closer.addEventListener('click', () => {
    form.style.transform = 'translateY(-2000%)'
})
loginLink.addEventListener('click', () => {
    if (loginLink.textContent == 'I already have an account'){
    username1.style.display = 'none'
    loginLink.textContent = 'New account'
    signUp.textContent = 'Sign In'
}else{
    username1.style.display = 'inline-block'
    loginLink.textContent = 'I already have an account'
    signUp.textContent = 'Sign Up'
        

    }
})
let show = document.getElementById('show')

show.addEventListener('click', () => {
    if(passw.getAttribute('type') === 'password'){
    passw.setAttribute('type', 'text')
    show.textContent = 'Hide'
}else {
    passw.setAttribute('type', 'password')
    show.textContent = 'Show'

    }
})

let username = document.getElementById('username')
let user = prompt('what is your name ?')
localStorage.setItem('username', user)

if (user === '' || user === null){
    user = 'Buddy'
}else{
    user = user
    let specialEdition = user[0].toUpperCase() + user.slice(1).toLowerCase()
    username.textContent = specialEdition
    username1.setAttribute('value', specialEdition)
}

let darktheme = document.getElementById('dark')
let linkCss = document.getElementById('linkcss')

darktheme.addEventListener('click', () => {
    if (linkCss.getAttribute('href') === 'style.css'){
        linkCss.setAttribute('href', 'styledark.css')
        darktheme.textContent = 'Light'
        darktheme.style.background = '#FAEAB1'
    }else{
        linkCss.setAttribute('href', 'style.css')
        darktheme.textContent = 'Dark'
        darktheme.style.background = 'linear-gradient(to bottom right, #191919, rgb(141, 3, 141))'
        
    }
})
